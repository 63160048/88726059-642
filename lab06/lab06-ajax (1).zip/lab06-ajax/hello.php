<?php
// hello.php
$fname = $_GET['fname'];
$lname = $_GET['lname'];
echo "Hello $fname $lname";

//if ($name=="witty")
//  echo "User name already exists.";